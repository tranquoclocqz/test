/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'widget', 'it', {
	'move': 'Fare clic e trascinare per spostare',
	'label': 'Widget %1'
} );
